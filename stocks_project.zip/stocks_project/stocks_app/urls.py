from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('plot_stock/', views.plot_stock, name='plot_stock'),
]
