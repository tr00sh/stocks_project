from django.shortcuts import render
import yfinance as yf
import plotly.graph_objs as go

def home(request):
    return render(request, 'stocks_app/home.html')

def plot_stock(request):
    if request.method == 'POST':
        stock_symbol = request.POST['stock_symbol']
        start_date = request.POST['start_date']
        end_date = request.POST['end_date']
        
        stock_data = yf.download(stock_symbol, start=start_date, end=end_date)
        
        # Creating plotly graph
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=stock_data.index, y=stock_data['Close'], mode='lines', name='Close Price'))
        fig.update_layout(title=f'{stock_symbol} سعر سهم', xaxis_title='Date', yaxis_title='Price')
        
        plot_div = fig.to_html(full_html=False)

        return render(request, 'stocks_app/home.html', {'plot_div': plot_div})
