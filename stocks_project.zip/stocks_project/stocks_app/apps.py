from django.apps import AppConfig


class StocksAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stocks_app'
